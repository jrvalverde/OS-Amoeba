LIBRARY OLDX
VERSION LIBRARY_VERSION
EXPORTS
 XDraw
 XDrawFilled
 XCreateAssocTable
 XDeleteAssoc
 XDestroyAssocTable
 XLookUpAssoc
 XMakeAssoc
