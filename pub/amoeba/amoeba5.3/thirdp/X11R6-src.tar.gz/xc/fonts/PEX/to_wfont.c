
# line 2 "to_wfont.y"
/* $XConsortium: to_wfont.y,v 5.8 94/11/21 17:11:41 kaleb Exp $ */

/*****************************************************************

Copyright (c) 1989,1990, 1991  X Consortium

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
X CONSORTIUM BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Except as contained in this notice, the name of the X Consortium shall not be
used in advertising or otherwise to promote the sale, use or other dealings
in this Software without prior written authorization from the X Consortium.

Copyright (c) 1989,1990, 1991 by Sun Microsystems, Inc.

                        All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the names of Sun Microsystems,
and the X Consortium, not be used in advertising or publicity 
pertaining to distribution of the software without specific, written 
prior permission.  

SUN MICROSYSTEMS DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT 
SHALL SUN MICROSYSTEMS BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL 
DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.

******************************************************************/


#define YYMAXDEPTH 10000

#include <X11/Xos.h>
#include <stdio.h>
#ifndef L_SET
#define L_SET SEEK_SET
#endif
#include "wfont.h"

#ifdef X_NOT_STDC_ENV
FILE *fopen();
#endif

typedef struct {

        float           std_left,      /* NCGA standard left spacing */
                        std_wide,      /* character width            */  
                        std_rght;      /* Right spacing              */  
}               Standard;


char            fname[80];
Dispatch        *Table;    /* dispatch table */
Standard	*sp_table; /* NCGA font spacings */
Path            *strokes;  /* strokes of each character */
Property        *property; /* property list */

struct {
	int path, point, props;
} count, expect;

Path_subpath   *current_path;

Font_header     head;		/* font header */
int             tableindex;	/* which character */
int             yyerrno;	/* error number */


# line 92 "to_wfont.y"
typedef union
#ifdef __cplusplus
	YYSTYPE
#endif
 {
	int	nil;	/* void is reserved */
	int	ival;
	float	dval;
	char	*cval;
} YYSTYPE;
# define REAL 257
# define INTEGER 258
# define STRING 259
# define BOTTOM 260
# define CENTER 261
# define CLOSE 262
# define FONTNAME 263
# define PROPERTIES 264
# define NUM_CH 265
# define INDEX 266
# define L_SPACE 267
# define MAGIC 268
# define OPEN 269
# define RIGHT 270
# define R_SPACE 271
# define STROKE 272
# define TOP 273
# define VERTICES 274
# define BEARING 275
# define WIDTH 276

#ifdef __STDC__
#include <stdlib.h>
#include <string.h>
#else
#include <malloc.h>
#include <memory.h>
#endif

#include <values.h>

#ifdef __cplusplus

#ifndef yyerror
	void yyerror(const char *);
#endif

#ifndef yylex
#ifdef __EXTERN_C__
	extern "C" { int yylex(void); }
#else
	int yylex(void);
#endif
#endif
	int yyparse(void);

#endif
#define yyclearin yychar = -1
#define yyerrok yyerrflag = 0
extern int yychar;
extern int yyerrflag;
YYSTYPE yylval;
YYSTYPE yyval;
typedef int yytabelem;
#ifndef YYMAXDEPTH
#define YYMAXDEPTH 150
#endif
#if YYMAXDEPTH > 0
int yy_yys[YYMAXDEPTH], *yys = yy_yys;
YYSTYPE yy_yyv[YYMAXDEPTH], *yyv = yy_yyv;
#else	/* user does initial allocation */
int *yys;
YYSTYPE *yyv;
#endif
static int yymaxdepth = YYMAXDEPTH;
# define YYERRCODE 256

# line 205 "to_wfont.y"


#define BYE(err)	yyerrno = (err), yyerror()

#define ERR_BASE	1000
#define OPEN_ERROR 	1001
#define WRITE_ERROR 	1002
#define WRONG_NAME 	1003
#define NO_MEMORY 	1004
#define EXCEED_PATH 	1005
#define EXCEED_POINT 	1006
#define PATH_MISMATCH	1007
#define POINT_MISMATCH	1008
#define PROP_MISMATCH   1009
#define EXCEED_PROPS 	1010

char	*prog;

main(argc, argv)
	int             argc;
	char           *argv[];

{
	/* Usage : to_wfont [-o outfile] [infile] */
	char           *s;

	fname[0] = 0;
	tableindex = 0;
	head.num_ch = -1;

	prog = *argv;
	while (--argc > 0 && *++argv != NULL) {
		s = *argv;
		if (*s++ == '-')
			switch (*s) {
			case 'o':
				if (*++argv != NULL)
				{
					--argc;
					(void) strcpy(fname, *argv);
				}
				break;
			default:      /* ignore other options */
				;
			}
		else {
			FILE           *fp;

			/* standard input redirection */
			fp = fopen(*argv, "r");
			if (fp != NULL) {
				if (close(fileno(stdin)) < 0)
				{
					perror(prog);
					return;
				}
				if (dup(fileno(fp)) < 0)
				{
					perror(prog);
					return;
				}
				(void) fclose(fp);
			}
		}
	}
	return (yyparse());
}

/* set number of characters */
set_num_ch(num_ch)
int num_ch;
{
	yyerrno = 0;
	head.num_ch = num_ch;
	if (num_ch > 0) {
	  Table    = (Dispatch *) malloc(num_ch * sizeof(Dispatch));
	  sp_table = (Standard *) malloc(num_ch * sizeof(Standard));
	  strokes  = (Path *)     malloc(num_ch * sizeof(Path));
	}

	for (tableindex = 0; tableindex < num_ch; tableindex++) {
		Table[tableindex].center = 0.0;
		Table[tableindex].right = 0.0;
		Table[tableindex].offset = 0;

		sp_table[tableindex].std_left = 0.0;
		sp_table[tableindex].std_wide = 0.0;
		sp_table[tableindex].std_rght = 0.0;

		strokes[tableindex].n_subpaths = 0;
		strokes[tableindex].n_vertices = 0;
		strokes[tableindex].subpaths = NULL;
	}
}

/* initialize the property info in the header */
init_properties(num_props)
	int             num_props;
{
	if (num_props > 0) {
	  head.properties = (Property *) 
	                      malloc (num_props * sizeof (Property));
	  head.num_props = expect.props = num_props;
	}
	else {
	  head.properties = NULL;
	  head.num_props = expect.props = 0;
	}
	count.props = -1;
	property = head.properties;  /* initialize the list pointer */
}

check_num_props()
{
        count.props++;
        if (count.props != expect.props)
	  BYE (PROP_MISMATCH);
}

/* add individual property info into the buffer */
add_property(name, value)
	char            *name,
			*value;
{
        /* check if the property exceeds allocated space */

        if (++count.props >= head.num_props)
	     BYE(EXCEED_PROPS);

	/* copy the strings into the buffer */

	(void) strcpy (property->propname, name);
	(void) strcpy (property->propvalue, value);

	/* increment the property pointer */

	property++;
}

check_num_ch()
{

  if (head.num_ch == -1)
	set_num_ch(128);

}

yyerror()
{
#if !defined(CSRG_BASED) && !defined(linux)
	extern int      yylineno;
#endif
#	define ERR_SIZE (sizeof(err_string) / sizeof(char *))
	static char    *err_string[] = {
		"Cannot open file",
		"Write fails",
		"Illegal font name",
		"Memory allocation failure",
		"Specified number of strokes exceeded",
		"Specified number of points exceeded",
		"Number of strokes do not match",
		"Number of points do not match",
		"Number of properties do not match",
		"Specified number of properties exceeded",
	0};
	char           *str;

	yyerrno -= ERR_BASE;
	if (yyerrno > 0 && yyerrno < ERR_SIZE)
		str = err_string[yyerrno-1];
	else
		str = "Syntax error";
#if !defined(CSRG_BASED) && !defined(linux)
		fprintf(stderr, "line %d: %s.\n", yylineno, str);
#else
		fprintf(stderr, "%s.\n", str);
#endif
	freeall();
	(void) unlink(fname);
	exit(1);
}

/* create wfont header */
wf_header(name, top, bottom)
	char           *name;
	float           top,
	                bottom;
{

	if (name == NULL)
		BYE(WRONG_NAME);
	head.top = (float) top;
	head.bottom = (float) bottom;
	head.magic = WFONT_MAGIC_PEX;
	(void) strcpy(head.name, name);
	free(name);
}

/* create header for each glyph */
glyph_header(npath, center, right, npts)
	int             npath,
	                npts;
	float           center,
	                right;
{
     {
	register Path  *strk = strokes + tableindex;
	
        if (npath > 0)     /* Don't allocate space unless the character
			      has strokes associated with it. */
	{
		strk->subpaths = (Path_subpath *)
			malloc(npath * sizeof (Path_subpath));

		if (strk->subpaths == NULL)
			BYE(NO_MEMORY);

		strk->type = PATH_2DF;
		strk->n_subpaths = npath;
		strk->n_vertices = npts;
	}
	else {            /* Just initialize the entry */
	        strk->subpaths = NULL;
		strk->type = PATH_2DF;
		strk->n_subpaths = 0;
		strk->n_vertices = 0;
	}
      }
      {
		register Dispatch *tbl = Table + tableindex;

		tbl->offset = 0;
		tbl->center = center;
		tbl->right = right;
      }
	count.path = -1;	       /* initialize path counter, not to
				        * exceed n_subpath */
}

/* create standard spacing info for each glyph  */
std_space(l_bear, wide, r_bear)

	float l_bear,
	      wide,
	      r_bear;
{
	register Standard *tbl = sp_table +tableindex;
	tbl->std_left = l_bear;
	tbl->std_wide = wide;
	tbl->std_rght = r_bear;
}

/* initialize each sub_path */
init_path(close, n)
	int             close,
	                n;
{
	register Path_subpath *path;

	if (++count.path >= strokes[tableindex].n_subpaths)
		BYE(EXCEED_PATH);
	path = current_path = strokes[tableindex].subpaths + count.path;
	path->n_pts = n;
	path->closed = close;
	if (n > 0) 
	  path->pts.pt2df = (Path_point2df *) 
	                     malloc(n * sizeof (Path_point2df));
	if (path->pts.pt2df == NULL)
		BYE(NO_MEMORY);
	expect.point = path->n_pts;
	count.point = -1;	       /* initialize point counter, not to
				        * exceed n_pts */
}

/* accumulating points for each sub_path */
add_point(x, y)
	float           x,
	                y;
{
	register Path_subpath   *path;
	register Path_point2df	*pt_ptr;

	path = current_path;
	if (++count.point >= path->n_pts)
		BYE(EXCEED_POINT);
	pt_ptr = path->pts.pt2df + count.point;
	pt_ptr->x = x;
	pt_ptr->y = y;
}

/* Path_type + n_subpaths + n_vertices */
#define STROKE_HEAD (sizeof (Path_type) + sizeof (int) + sizeof (int))

/* write out file, close everything, free everything */
fini()
{
	static long     zero = 0;

	/* pointers used to walk the arrays */
	register Path_subpath *spath;
	register Dispatch *tbl_ptr;
	register Path  *strptr;
	register Property *prop_ptr;

	FILE           *fp;
	long            offset;
	int             npath;
	register int    i,
	                j,
			k;
	Standard	*sp_ptr;
	Path_point2df	*pt;

	if (fname[0] == 0) {	       /* default output file name */
		(void) strcpy(fname, head.name);
		(void) strcat(fname, ".phont");
	}

	if ((fp = fopen(fname, "w")) == NULL)
		BYE(OPEN_ERROR);

#	define BY_BYE(err) fclose(fp), BYE(err)

	/* adjust the characters for spacing, note max char width */
	head.max_width = 0.0;
	for (i = 0, tbl_ptr = Table, strptr = strokes, sp_ptr = sp_table;
             i < head.num_ch; i++, tbl_ptr++, strptr++, sp_ptr++) {
		tbl_ptr->center += sp_ptr->std_left;
		tbl_ptr->right += sp_ptr->std_left + sp_ptr->std_rght;
		if (tbl_ptr->right > head.max_width)
			head.max_width = tbl_ptr->right;
		npath = strptr->n_subpaths;
		if (npath > 0 || tbl_ptr->center != 0.0 ||
                    tbl_ptr->right != 0.0) {
			for (j = 0, spath = strptr->subpaths;
                             j < npath; j++, spath++) {
				for(k=0, pt = spath->pts.pt2df;
				     k<spath->n_pts; k++, pt++) {
					pt->x += sp_ptr->std_left;
				}
			}
		}
	}
	/* write the header info */
	if (fwrite(&head, sizeof (head), 1, fp) != 1)
		BY_BYE(WRITE_ERROR);

	(void) fseek(fp, START_PROPS, L_SET);

	/* write the property info, if any */
	if (head.num_props > 0) {
	  for (i=0, prop_ptr = head.properties; i < head.num_props;
	       i++, prop_ptr++) {

	       /* write the property name */
	       if (fwrite(prop_ptr->propname, 80, 1, fp) != 1)
		  BY_BYE(WRITE_ERROR);

	       /* write the property value */
	       if (fwrite(prop_ptr->propvalue, 80, 1, fp) != 1)
		  BY_BYE(WRITE_ERROR);
	     }
	}

	(void) fseek(fp, START_DISPATCH(head.num_props), L_SET);
	offset = START_PATH(head.num_ch, head.num_props);


	/* write the dispatch table */
	for (i = 0, tbl_ptr = Table, strptr = strokes;
	     i < head.num_ch; i++, tbl_ptr++, strptr++) {
		if (fwrite(&tbl_ptr->center, sizeof (float), 1, fp) != 1 ||
		    fwrite(&tbl_ptr->right, sizeof (float), 1, fp) != 1)
			BY_BYE(WRITE_ERROR);
		npath = strptr->n_subpaths;
		if (npath > 0 || tbl_ptr->center != 0.0 ||
		    tbl_ptr->right != 0.0) {
			if (fwrite(&offset, sizeof (offset), 1, fp) != 1)
				BY_BYE(WRITE_ERROR);
			offset += STROKE_HEAD + npath * 2 * sizeof (int);
			for (j = 0, spath = strptr->subpaths;
			     j < npath; j++, spath++)
				offset += spath->n_pts * sizeof (Path_point2df);
		}
		else if (fwrite(&zero, sizeof (long), 1, fp) != 1)
			BY_BYE(WRITE_ERROR);
	}

	(void) fseek(fp, START_PATH(head.num_ch, head.num_props), L_SET);

	/* write the stroke table */
	for (i = 0, tbl_ptr = Table, strptr = strokes;
	     i < head.num_ch; i++, tbl_ptr++, strptr++) {
		if (strptr->n_subpaths > 0 ||
		    tbl_ptr->center != 0.0 ||
		    tbl_ptr->right != 0.0) {
			if (fwrite(strptr, STROKE_HEAD, 1, fp) != 1)
				BY_BYE(WRITE_ERROR);

			for (j = 0, spath = strptr->subpaths;
			     j < strptr->n_subpaths; j++, spath++) {

				if (fwrite(&spath->n_pts,
				       sizeof (spath->n_pts), 1, fp) != 1 ||
				    fwrite(&spath->closed,
				      sizeof (spath->closed), 1, fp) != 1 ||
				    fwrite(spath->pts.pt2df,
					   sizeof (Path_point2df),
					   spath->n_pts, fp) != spath->n_pts)
					BY_BYE(WRITE_ERROR);
			}
		}
	}

	(void) fclose(fp);
	freeall();
#	undef BY_BYE
}

freeall()
{
	register Path  *path;
	register Path_subpath *spath;
	register int    i,
	                j,
	                n;

	path = strokes;
	for (i = 0; i < head.num_ch; i++, path++) {
		n = path->n_subpaths;
		if (n <= 0)
			continue;
		spath = path->subpaths;
		for (j = 0; j < n; j++, spath++)
			if (spath->pts.pt2df != NULL)
				free((char *) spath->pts.pt2df);
		if (path->subpaths != NULL)
			free((char *) path->subpaths);
	free(Table);
	free(sp_table);
	free(strokes);
	}
	for (i=0; i < head.num_props; i++, head.properties++) {
	  if (head.properties != NULL)
	    free((char *) head.properties);
	}
}

check_nstroke()
{
	count.path++;
	if (expect.path != count.path)
		BYE(PATH_MISMATCH);
}

check_npts()
{
	count.point++;
	if (expect.point != count.point)
		BYE(POINT_MISMATCH);
}
yytabelem yyexca[] ={
-1, 1,
	0, -1,
	-2, 0,
	};
# define YYNPROD 45
# define YYLAST 93
yytabelem yyact[]={

    70,    42,    67,    13,    37,    74,    58,    23,    61,     7,
    11,    17,    11,     4,    24,    46,    28,    63,    53,    14,
    72,    50,    47,    34,    31,    26,    18,    76,    75,    71,
    68,    65,    56,    59,    38,    29,    54,    51,    39,    20,
     6,    49,    40,    55,    44,    21,    35,    25,     9,    19,
     8,    52,    43,    15,     2,    73,    30,    69,    60,    41,
    22,    32,     5,    10,    33,    66,    36,    57,    45,    27,
    12,    16,     3,     1,     0,     0,     0,     0,     0,    48,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
    62,     0,    64 };
yytabelem yypact[]={

  -250,-10000000,  -256,  -270,  -240,  -253,-10000000,  -232,  -254,  -255,
-10000000,  -233,  -244,  -222,-10000000,  -254,-10000000,  -234,-10000000,-10000000,
-10000000,  -255,  -235,-10000000,-10000000,  -268,-10000000,-10000000,  -223,-10000000,
  -274,-10000000,-10000000,-10000000,-10000000,-10000000,  -246,  -236,-10000000,-10000000,
  -274,-10000000,  -237,  -241,  -225,  -264,  -224,-10000000,-10000000,  -259,
-10000000,-10000000,  -241,  -242,-10000000,  -225,  -226,  -272,  -227,-10000000,
  -276,  -228,-10000000,-10000000,-10000000,-10000000,-10000000,  -238,-10000000,  -266,
  -229,-10000000,-10000000,-10000000,  -230,-10000000,-10000000 };
yytabelem yypgo[]={

     0,    73,    72,    71,    70,    69,    68,    67,    66,    65,
    64,    63,    62,    60,    59,    58,    57,    55,    54,    53,
    40,    38,    52,    37,    51,    50,    48,    39,    47,    46,
    45,    44,    36,    43,    42,    41 };
yytabelem yyr1[]={

     0,     1,     1,    18,     2,     4,     5,    12,    19,    19,
    22,     3,    23,    23,    24,    20,    20,    25,    28,    26,
    29,    11,     8,     9,     9,     6,     7,    27,    27,    31,
    30,    32,    32,    13,    13,    10,    33,    21,    21,    35,
    34,    14,    15,    16,    17 };
yytabelem yyr2[]={

     0,    11,     5,     7,     5,     5,     5,     5,     0,     2,
     1,     9,     0,     4,     5,     0,     4,     5,     1,     6,
     9,     5,     5,     1,     5,     5,     5,     0,     4,     1,
     9,     0,     4,     3,     3,     3,     5,     0,     4,     1,
    11,     5,     5,     5,     5 };
yytabelem yychk[]={

-10000000,    -1,   -18,    -2,   263,   -12,   -20,   265,   -25,   -26,
   -11,   266,    -4,   273,   259,   -19,    -3,   264,   258,   -20,
   -27,   -30,   -13,   262,   269,   -28,   258,    -5,   260,   257,
   -20,   258,   -27,   -10,   258,   -29,    -8,   272,   257,   -21,
   -34,   -14,   275,   -22,   -31,    -6,   261,   258,   -21,   -35,
   258,   -23,   -24,   259,   -32,   -33,   257,    -7,   270,   257,
   -15,   267,   -23,   259,   -32,   257,    -9,   274,   257,   -16,
   276,   257,   258,   -17,   271,   257,   257 };
yytabelem yydef[]={

     0,    -2,    15,     0,     0,     8,     2,     0,    15,    27,
    18,     0,     0,     0,     4,    15,     9,     0,     7,    16,
    17,    27,     0,    33,    34,     0,    21,     3,     0,     5,
    37,    10,    28,    29,    35,    19,     0,     0,     6,     1,
    37,    39,     0,    12,    31,     0,     0,    22,    38,     0,
    41,    11,    12,     0,    30,    31,     0,    23,     0,    25,
     0,     0,    13,    14,    32,    36,    20,     0,    26,     0,
     0,    42,    24,    40,     0,    43,    44 };
typedef struct
#ifdef __cplusplus
	yytoktype
#endif
{ char *t_name; int t_val; } yytoktype;
#ifndef YYDEBUG
#	define YYDEBUG	0	/* don't allow debugging */
#endif

#if YYDEBUG

yytoktype yytoks[] =
{
	"REAL",	257,
	"INTEGER",	258,
	"STRING",	259,
	"BOTTOM",	260,
	"CENTER",	261,
	"CLOSE",	262,
	"FONTNAME",	263,
	"PROPERTIES",	264,
	"NUM_CH",	265,
	"INDEX",	266,
	"L_SPACE",	267,
	"MAGIC",	268,
	"OPEN",	269,
	"RIGHT",	270,
	"R_SPACE",	271,
	"STROKE",	272,
	"TOP",	273,
	"VERTICES",	274,
	"BEARING",	275,
	"WIDTH",	276,
	"-unknown-",	-1	/* ends search */
};

char * yyreds[] =
{
	"-no such reduction-",
	"font : fontheader num_ch fontprops fontbody spacing",
	"font : fontheader fontbody",
	"fontheader : fontname top bottom",
	"fontname : FONTNAME STRING",
	"top : TOP REAL",
	"bottom : BOTTOM REAL",
	"num_ch : NUM_CH INTEGER",
	"fontprops : /* empty */",
	"fontprops : properties",
	"properties : PROPERTIES INTEGER",
	"properties : PROPERTIES INTEGER property_list",
	"property_list : /* empty */",
	"property_list : single_property property_list",
	"single_property : STRING STRING",
	"fontbody : /* empty */",
	"fontbody : glyph fontbody",
	"glyph : glyph_header strokes",
	"glyph_header : index",
	"glyph_header : index sym_headinfo",
	"sym_headinfo : nstroke center right nvertice",
	"index : INDEX INTEGER",
	"nstroke : STROKE INTEGER",
	"nvertice : /* empty */",
	"nvertice : VERTICES INTEGER",
	"center : CENTER REAL",
	"right : RIGHT REAL",
	"strokes : /* empty */",
	"strokes : path strokes",
	"path : closeflag n_pts",
	"path : closeflag n_pts points",
	"points : /* empty */",
	"points : coord points",
	"closeflag : CLOSE",
	"closeflag : OPEN",
	"n_pts : INTEGER",
	"coord : REAL REAL",
	"spacing : /* empty */",
	"spacing : item spacing",
	"item : counter",
	"item : counter sp_left wide sp_right",
	"counter : BEARING INTEGER",
	"sp_left : L_SPACE REAL",
	"wide : WIDTH REAL",
	"sp_right : R_SPACE REAL",
};
#endif /* YYDEBUG */
/*
 * Copyright (c) 1993 by Sun Microsystems, Inc.
 */

#pragma ident	"@(#)yaccpar	6.12	93/06/07 SMI"

/*
** Skeleton parser driver for yacc output
*/

/*
** yacc user known macros and defines
*/
#define YYERROR		goto yyerrlab
#define YYACCEPT	return(0)
#define YYABORT		return(1)
#define YYBACKUP( newtoken, newvalue )\
{\
	if ( yychar >= 0 || ( yyr2[ yytmp ] >> 1 ) != 1 )\
	{\
		yyerror( "syntax error - cannot backup" );\
		goto yyerrlab;\
	}\
	yychar = newtoken;\
	yystate = *yyps;\
	yylval = newvalue;\
	goto yynewstate;\
}
#define YYRECOVERING()	(!!yyerrflag)
#define YYNEW(type)	malloc(sizeof(type) * yynewmax)
#define YYCOPY(to, from, type) \
	(type *) memcpy(to, (char *) from, yynewmax * sizeof(type))
#define YYENLARGE( from, type) \
	(type *) realloc((char *) from, yynewmax * sizeof(type))
#ifndef YYDEBUG
#	define YYDEBUG	1	/* make debugging available */
#endif

/*
** user known globals
*/
int yydebug;			/* set to 1 to get debugging */

/*
** driver internal defines
*/
#define YYFLAG		(-10000000)

/*
** global variables used by the parser
*/
YYSTYPE *yypv;			/* top of value stack */
int *yyps;			/* top of state stack */

int yystate;			/* current state */
int yytmp;			/* extra var (lasts between blocks) */

int yynerrs;			/* number of errors */
int yyerrflag;			/* error recovery flag */
int yychar;			/* current input token number */



#ifdef YYNMBCHARS
#define YYLEX()		yycvtok(yylex())
/*
** yycvtok - return a token if i is a wchar_t value that exceeds 255.
**	If i<255, i itself is the token.  If i>255 but the neither 
**	of the 30th or 31st bit is on, i is already a token.
*/
#if defined(__STDC__) || defined(__cplusplus)
int yycvtok(int i)
#else
int yycvtok(i) int i;
#endif
{
	int first = 0;
	int last = YYNMBCHARS - 1;
	int mid;
	wchar_t j;

	if(i&0x60000000){/*Must convert to a token. */
		if( yymbchars[last].character < i ){
			return i;/*Giving up*/
		}
		while ((last>=first)&&(first>=0)) {/*Binary search loop*/
			mid = (first+last)/2;
			j = yymbchars[mid].character;
			if( j==i ){/*Found*/ 
				return yymbchars[mid].tvalue;
			}else if( j<i ){
				first = mid + 1;
			}else{
				last = mid -1;
			}
		}
		/*No entry in the table.*/
		return i;/* Giving up.*/
	}else{/* i is already a token. */
		return i;
	}
}
#else/*!YYNMBCHARS*/
#define YYLEX()		yylex()
#endif/*!YYNMBCHARS*/

/*
** yyparse - return 0 if worked, 1 if syntax error not recovered from
*/
#if defined(__STDC__) || defined(__cplusplus)
int yyparse(void)
#else
int yyparse()
#endif
{
	register YYSTYPE *yypvt;	/* top of value stack for $vars */

#if defined(__cplusplus) || defined(lint)
/*
	hacks to please C++ and lint - goto's inside switch should never be
	executed; yypvt is set to 0 to avoid "used before set" warning.
*/
	static int __yaccpar_lint_hack__ = 0;
	switch (__yaccpar_lint_hack__)
	{
		case 1: goto yyerrlab;
		case 2: goto yynewstate;
	}
	yypvt = 0;
#endif

	/*
	** Initialize externals - yyparse may be called more than once
	*/
	yypv = &yyv[-1];
	yyps = &yys[-1];
	yystate = 0;
	yytmp = 0;
	yynerrs = 0;
	yyerrflag = 0;
	yychar = -1;

#if YYMAXDEPTH <= 0
	if (yymaxdepth <= 0)
	{
		if ((yymaxdepth = YYEXPAND(0)) <= 0)
		{
			yyerror("yacc initialization error");
			YYABORT;
		}
	}
#endif

	{
		register YYSTYPE *yy_pv;	/* top of value stack */
		register int *yy_ps;		/* top of state stack */
		register int yy_state;		/* current state */
		register int  yy_n;		/* internal state number info */
	goto yystack;	/* moved from 6 lines above to here to please C++ */

		/*
		** get globals into registers.
		** branch to here only if YYBACKUP was called.
		*/
	yynewstate:
		yy_pv = yypv;
		yy_ps = yyps;
		yy_state = yystate;
		goto yy_newstate;

		/*
		** get globals into registers.
		** either we just started, or we just finished a reduction
		*/
	yystack:
		yy_pv = yypv;
		yy_ps = yyps;
		yy_state = yystate;

		/*
		** top of for (;;) loop while no reductions done
		*/
	yy_stack:
		/*
		** put a state and value onto the stacks
		*/
#if YYDEBUG
		/*
		** if debugging, look up token value in list of value vs.
		** name pairs.  0 and negative (-1) are special values.
		** Note: linear search is used since time is not a real
		** consideration while debugging.
		*/
		if ( yydebug )
		{
			register int yy_i;

			printf( "State %d, token ", yy_state );
			if ( yychar == 0 )
				printf( "end-of-file\n" );
			else if ( yychar < 0 )
				printf( "-none-\n" );
			else
			{
				for ( yy_i = 0; yytoks[yy_i].t_val >= 0;
					yy_i++ )
				{
					if ( yytoks[yy_i].t_val == yychar )
						break;
				}
				printf( "%s\n", yytoks[yy_i].t_name );
			}
		}
#endif /* YYDEBUG */
		if ( ++yy_ps >= &yys[ yymaxdepth ] )	/* room on stack? */
		{
			/*
			** reallocate and recover.  Note that pointers
			** have to be reset, or bad things will happen
			*/
			int yyps_index = (yy_ps - yys);
			int yypv_index = (yy_pv - yyv);
			int yypvt_index = (yypvt - yyv);
			int yynewmax;
#ifdef YYEXPAND
			yynewmax = YYEXPAND(yymaxdepth);
#else
			yynewmax = 2 * yymaxdepth;	/* double table size */
			if (yymaxdepth == YYMAXDEPTH)	/* first time growth */
			{
				char *newyys = (char *)YYNEW(int);
				char *newyyv = (char *)YYNEW(YYSTYPE);
				if (newyys != 0 && newyyv != 0)
				{
					yys = YYCOPY(newyys, yys, int);
					yyv = YYCOPY(newyyv, yyv, YYSTYPE);
				}
				else
					yynewmax = 0;	/* failed */
			}
			else				/* not first time */
			{
				yys = YYENLARGE(yys, int);
				yyv = YYENLARGE(yyv, YYSTYPE);
				if (yys == 0 || yyv == 0)
					yynewmax = 0;	/* failed */
			}
#endif
			if (yynewmax <= yymaxdepth)	/* tables not expanded */
			{
				yyerror( "yacc stack overflow" );
				YYABORT;
			}
			yymaxdepth = yynewmax;

			yy_ps = yys + yyps_index;
			yy_pv = yyv + yypv_index;
			yypvt = yyv + yypvt_index;
		}
		*yy_ps = yy_state;
		*++yy_pv = yyval;

		/*
		** we have a new state - find out what to do
		*/
	yy_newstate:
		if ( ( yy_n = yypact[ yy_state ] ) <= YYFLAG )
			goto yydefault;		/* simple state */
#if YYDEBUG
		/*
		** if debugging, need to mark whether new token grabbed
		*/
		yytmp = yychar < 0;
#endif
		if ( ( yychar < 0 ) && ( ( yychar = YYLEX() ) < 0 ) )
			yychar = 0;		/* reached EOF */
#if YYDEBUG
		if ( yydebug && yytmp )
		{
			register int yy_i;

			printf( "Received token " );
			if ( yychar == 0 )
				printf( "end-of-file\n" );
			else if ( yychar < 0 )
				printf( "-none-\n" );
			else
			{
				for ( yy_i = 0; yytoks[yy_i].t_val >= 0;
					yy_i++ )
				{
					if ( yytoks[yy_i].t_val == yychar )
						break;
				}
				printf( "%s\n", yytoks[yy_i].t_name );
			}
		}
#endif /* YYDEBUG */
		if ( ( ( yy_n += yychar ) < 0 ) || ( yy_n >= YYLAST ) )
			goto yydefault;
		if ( yychk[ yy_n = yyact[ yy_n ] ] == yychar )	/*valid shift*/
		{
			yychar = -1;
			yyval = yylval;
			yy_state = yy_n;
			if ( yyerrflag > 0 )
				yyerrflag--;
			goto yy_stack;
		}

	yydefault:
		if ( ( yy_n = yydef[ yy_state ] ) == -2 )
		{
#if YYDEBUG
			yytmp = yychar < 0;
#endif
			if ( ( yychar < 0 ) && ( ( yychar = YYLEX() ) < 0 ) )
				yychar = 0;		/* reached EOF */
#if YYDEBUG
			if ( yydebug && yytmp )
			{
				register int yy_i;

				printf( "Received token " );
				if ( yychar == 0 )
					printf( "end-of-file\n" );
				else if ( yychar < 0 )
					printf( "-none-\n" );
				else
				{
					for ( yy_i = 0;
						yytoks[yy_i].t_val >= 0;
						yy_i++ )
					{
						if ( yytoks[yy_i].t_val
							== yychar )
						{
							break;
						}
					}
					printf( "%s\n", yytoks[yy_i].t_name );
				}
			}
#endif /* YYDEBUG */
			/*
			** look through exception table
			*/
			{
				register int *yyxi = yyexca;

				while ( ( *yyxi != -1 ) ||
					( yyxi[1] != yy_state ) )
				{
					yyxi += 2;
				}
				while ( ( *(yyxi += 2) >= 0 ) &&
					( *yyxi != yychar ) )
					;
				if ( ( yy_n = yyxi[1] ) < 0 )
					YYACCEPT;
			}
		}

		/*
		** check for syntax error
		*/
		if ( yy_n == 0 )	/* have an error */
		{
			/* no worry about speed here! */
			switch ( yyerrflag )
			{
			case 0:		/* new error */
				yyerror( "syntax error" );
				goto skip_init;
			yyerrlab:
				/*
				** get globals into registers.
				** we have a user generated syntax type error
				*/
				yy_pv = yypv;
				yy_ps = yyps;
				yy_state = yystate;
			skip_init:
				yynerrs++;
				/* FALLTHRU */
			case 1:
			case 2:		/* incompletely recovered error */
					/* try again... */
				yyerrflag = 3;
				/*
				** find state where "error" is a legal
				** shift action
				*/
				while ( yy_ps >= yys )
				{
					yy_n = yypact[ *yy_ps ] + YYERRCODE;
					if ( yy_n >= 0 && yy_n < YYLAST &&
						yychk[yyact[yy_n]] == YYERRCODE)					{
						/*
						** simulate shift of "error"
						*/
						yy_state = yyact[ yy_n ];
						goto yy_stack;
					}
					/*
					** current state has no shift on
					** "error", pop stack
					*/
#if YYDEBUG
#	define _POP_ "Error recovery pops state %d, uncovers state %d\n"
					if ( yydebug )
						printf( _POP_, *yy_ps,
							yy_ps[-1] );
#	undef _POP_
#endif
					yy_ps--;
					yy_pv--;
				}
				/*
				** there is no state on stack with "error" as
				** a valid shift.  give up.
				*/
				YYABORT;
			case 3:		/* no shift yet; eat a token */
#if YYDEBUG
				/*
				** if debugging, look up token in list of
				** pairs.  0 and negative shouldn't occur,
				** but since timing doesn't matter when
				** debugging, it doesn't hurt to leave the
				** tests here.
				*/
				if ( yydebug )
				{
					register int yy_i;

					printf( "Error recovery discards " );
					if ( yychar == 0 )
						printf( "token end-of-file\n" );
					else if ( yychar < 0 )
						printf( "token -none-\n" );
					else
					{
						for ( yy_i = 0;
							yytoks[yy_i].t_val >= 0;
							yy_i++ )
						{
							if ( yytoks[yy_i].t_val
								== yychar )
							{
								break;
							}
						}
						printf( "token %s\n",
							yytoks[yy_i].t_name );
					}
				}
#endif /* YYDEBUG */
				if ( yychar == 0 )	/* reached EOF. quit */
					YYABORT;
				yychar = -1;
				goto yy_newstate;
			}
		}/* end if ( yy_n == 0 ) */
		/*
		** reduction by production yy_n
		** put stack tops, etc. so things right after switch
		*/
#if YYDEBUG
		/*
		** if debugging, print the string that is the user's
		** specification of the reduction which is just about
		** to be done.
		*/
		if ( yydebug )
			printf( "Reduce by (%d) \"%s\"\n",
				yy_n, yyreds[ yy_n ] );
#endif
		yytmp = yy_n;			/* value to switch over */
		yypvt = yy_pv;			/* $vars top of value stack */
		/*
		** Look in goto table for next state
		** Sorry about using yy_state here as temporary
		** register variable, but why not, if it works...
		** If yyr2[ yy_n ] doesn't have the low order bit
		** set, then there is no action to be done for
		** this reduction.  So, no saving & unsaving of
		** registers done.  The only difference between the
		** code just after the if and the body of the if is
		** the goto yy_stack in the body.  This way the test
		** can be made before the choice of what to do is needed.
		*/
		{
			/* length of production doubled with extra bit */
			register int yy_len = yyr2[ yy_n ];

			if ( !( yy_len & 01 ) )
			{
				yy_len >>= 1;
				yyval = ( yy_pv -= yy_len )[1];	/* $$ = $1 */
				yy_state = yypgo[ yy_n = yyr1[ yy_n ] ] +
					*( yy_ps -= yy_len ) + 1;
				if ( yy_state >= YYLAST ||
					yychk[ yy_state =
					yyact[ yy_state ] ] != -yy_n )
				{
					yy_state = yyact[ yypgo[ yy_n ] ];
				}
				goto yy_stack;
			}
			yy_len >>= 1;
			yyval = ( yy_pv -= yy_len )[1];	/* $$ = $1 */
			yy_state = yypgo[ yy_n = yyr1[ yy_n ] ] +
				*( yy_ps -= yy_len ) + 1;
			if ( yy_state >= YYLAST ||
				yychk[ yy_state = yyact[ yy_state ] ] != -yy_n )
			{
				yy_state = yyact[ yypgo[ yy_n ] ];
			}
		}
					/* save until reenter driver code */
		yystate = yy_state;
		yyps = yy_ps;
		yypv = yy_pv;
	}
	/*
	** code supplied by user is placed in this switch
	*/
	switch( yytmp )
	{
		
case 1:
# line 133 "to_wfont.y"
{ fini(); } break;
case 2:
# line 134 "to_wfont.y"
{ fini(); } break;
case 3:
# line 137 "to_wfont.y"
{ wf_header(yypvt[-2].cval, yypvt[-1].dval, yypvt[-0].dval); } break;
case 4:
# line 140 "to_wfont.y"
{ yyval.cval = yypvt[-0].cval; } break;
case 5:
# line 142 "to_wfont.y"
{ yyval.dval = yypvt[-0].dval;} break;
case 6:
# line 144 "to_wfont.y"
{ yyval.dval = yypvt[-0].dval;} break;
case 7:
# line 146 "to_wfont.y"
{ set_num_ch(yypvt[-0].ival);} break;
case 10:
# line 150 "to_wfont.y"
{ init_properties (yypvt[-0].ival); } break;
case 11:
# line 151 "to_wfont.y"
{ check_num_props (); } break;
case 14:
# line 155 "to_wfont.y"
{ add_property(yypvt[-1].cval, yypvt[-0].cval); } break;
case 17:
# line 161 "to_wfont.y"
{ check_nstroke(); } break;
case 18:
# line 163 "to_wfont.y"
{ tableindex = yypvt[-0].ival; } break;
case 20:
# line 166 "to_wfont.y"
{ glyph_header(yypvt[-3].ival, yypvt[-2].dval, yypvt[-1].dval, yypvt[-0].ival); } break;
case 21:
# line 168 "to_wfont.y"
{ check_num_ch(); yyval.ival = yypvt[-0].ival; } break;
case 22:
# line 170 "to_wfont.y"
{ yyval.ival = yypvt[-0].ival; expect.path = yypvt[-0].ival; } break;
case 23:
# line 172 "to_wfont.y"
{yyval.ival = 0;} break;
case 24:
# line 172 "to_wfont.y"
{ yyval.ival = yypvt[-0].ival; } break;
case 25:
# line 174 "to_wfont.y"
{ yyval.dval = yypvt[-0].dval; } break;
case 26:
# line 176 "to_wfont.y"
{ yyval.dval = yypvt[-0].dval; } break;
case 29:
# line 180 "to_wfont.y"
{ init_path(yypvt[-1].ival, yypvt[-0].ival); } break;
case 30:
# line 181 "to_wfont.y"
{ check_npts(); } break;
case 33:
# line 185 "to_wfont.y"
{ yyval.ival = yypvt[-0].nil == CLOSE; } break;
case 34:
# line 185 "to_wfont.y"
{ yyval.ival = yypvt[-0].nil == CLOSE; } break;
case 35:
# line 187 "to_wfont.y"
{ yyval.ival = yypvt[-0].ival; } break;
case 36:
# line 189 "to_wfont.y"
{ add_point(yypvt[-1].dval, yypvt[-0].dval); } break;
case 39:
# line 194 "to_wfont.y"
{tableindex = yypvt[-0].ival;} break;
case 40:
# line 195 "to_wfont.y"
{ std_space(yypvt[-2].dval, yypvt[-1].dval, yypvt[-0].dval); } break;
case 41:
# line 197 "to_wfont.y"
{yyval.ival = yypvt[-0].ival;} break;
case 42:
# line 199 "to_wfont.y"
{yyval.dval = yypvt[-0].dval;} break;
case 43:
# line 201 "to_wfont.y"
{yyval.dval = yypvt[-0].dval;} break;
case 44:
# line 203 "to_wfont.y"
{yyval.dval = yypvt[-0].dval;} break;
	}
	goto yystack;		/* reset registers in driver code */
}

