
typedef union
#ifdef __cplusplus
	YYSTYPE
#endif
 {
	int	nil;	/* void is reserved */
	int	ival;
	float	dval;
	char	*cval;
} YYSTYPE;
extern YYSTYPE yylval;
# define REAL 257
# define INTEGER 258
# define STRING 259
# define BOTTOM 260
# define CENTER 261
# define CLOSE 262
# define FONTNAME 263
# define PROPERTIES 264
# define NUM_CH 265
# define INDEX 266
# define L_SPACE 267
# define MAGIC 268
# define OPEN 269
# define RIGHT 270
# define R_SPACE 271
# define STROKE 272
# define TOP 273
# define VERTICES 274
# define BEARING 275
# define WIDTH 276
